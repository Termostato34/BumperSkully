# Teleport the player up so they don't get caught in the ground
execute as @a at @s run tp @s ~ ~1 ~

# Replace the island with air
fill 0 58 -4 15 76 18 minecraft:air
kill @e[type=item]
# Place the default island
function skyblock:main_island_generation/seed/island_place/plaines