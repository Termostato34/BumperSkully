execute positioned 4 59 5 run place template skyblock:starting_islands/lush_caves
scoreboard players set $lush_cave skyblock.outer_island_checklist 1