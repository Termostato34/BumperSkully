execute positioned 5 61 5 run place template skyblock:starting_islands/snowy_slopes
scoreboard players set $mountains skyblock.outer_island_checklist 1