# Dry Grass
execute if score $desert skyblock.outer_island_checklist matches 1 \
    run give @s minecraft:tall_dry_grass
execute if score $badlands skyblock.outer_island_checklist matches 1 \
    run give @s minecraft:tall_dry_grass
# Bush
execute if score $birch skyblock.outer_island_checklist matches 1 \
    run give @s minecraft:bush
#Firefly Bush
execute if score $mangrove skyblock.outer_island_checklist matches 1 \
    run give @s minecraft:firefly_bush
