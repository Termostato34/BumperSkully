# Block Display
execute if score $player_choice skyblock.new_world = $no skyblock.new_world run summon block_display ~ ~ ~ {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[1f,1f,1f]},block_state:{Name:"minecraft:iron_block"},Tags:["skyblock.config_menu"]}
execute if score $player_choice skyblock.new_world = $yes skyblock.new_world run summon block_display ~ ~ ~ {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[1f,1f,1f]},block_state:{Name:"minecraft:diamond_block"},Tags:["skyblock.config_menu"]}
# Interation
summon interaction ~ ~ ~ {UUID:[I;1792225511,1900890754,-1225949765,972316987],response:1b,Tags:["skyblock.config_menu"]}
# Text Displays
execute positioned ~-0.6 ~1 ~ summon minecraft:text_display run data merge entity @s {text:{"text":"World Type"},Rotation:[90F,0F],Tags:["skyblock.option-name","skyblock.config_menu"]}
execute if score $player_choice skyblock.new_world = $no skyblock.new_world positioned ~-0.6 ~ ~ summon minecraft:text_display run data merge entity @s {text:{"text":"Old"},Rotation:[90F,0F],Tags:["skyblock.selected-option","skyblock.config_menu"],background:16777215,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.72f,0.72f,0.72f]}}
execute if score $player_choice skyblock.new_world = $yes skyblock.new_world positioned ~-0.6 ~ ~ summon minecraft:text_display run data merge entity @s {text:{"text":"New"},Rotation:[90F,0F],Tags:["skyblock.selected-option","skyblock.config_menu"],background:16777215,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.65f,0.65f,0.65f]}}
