place template skyblock:outer_islands/pale_oak 580 61 1
scoreboard players set $pale_oak skyblock.outer_island_checklist 1 