execute positioned 2 61 4 run place template skyblock:starting_islands/pale_oak
scoreboard players set $pale_oak skyblock.outer_island_checklist 1