# Place Island
place template skyblock:outer_islands/pale_oak
# Mark as generated
scoreboard players set $pale_oak skyblock.outer_island_checklist 1 
# An island has been placed
scoreboard players set $found_island skyblock.outer_island_checklist 1